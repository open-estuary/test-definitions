#!/bin/bash

if $(which yum); then
	yum install -y numactl
fi

if $(which apt-get); then
	apt-get install -y numactl
fi

cd lmbench-3.0-a9
sed -i s/-O\ /-O2\ /g src/Makefile

make OS=lmbench
