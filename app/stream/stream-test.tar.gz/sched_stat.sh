#!/bin/sh

cmd=python
#ps -o pid,cmd -xH | grep $cmd
plist=`ps -o pid,cmd -xH | grep $cmd | awk '{print $1}'`
echo $plist
for pid in $plist;do
	echo -n "$pid: "
	cat /proc/$pid/comm
	grep "Cpus_allowed" /proc/$pid/status
done
