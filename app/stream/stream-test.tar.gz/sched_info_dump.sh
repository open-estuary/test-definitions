#!/bin/bash

for f in /proc/sys/kernel/sched*;do
	if [ -d $f ];then
		continue
	fi
	echo -n "$f: "
	cat $f
done

for f in /proc/sys/kernel/sched_domain/cpu0/domain0/*;do
	echo -n "$f: "
	cat $f
done
for f in /proc/sys/kernel/sched_domain/cpu0/domain1/*;do
	echo -n "$f: "
	cat $f
done
for f in /proc/sys/kernel/sched_domain/cpu0/domain2/*;do
	echo -n "$f: "
	cat $f
done
